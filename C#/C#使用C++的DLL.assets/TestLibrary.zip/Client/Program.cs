﻿
using  CSharpLib;
using System.Runtime.InteropServices;

namespace Client
{
    class Program
    {

        [DllImport("Hello.dll")]
        extern static int doubleIt(int x);

        [DllImport("Hello.dll")]
        extern static IntPtr establishAdder();

        [DllImport("Hello.dll")]
        extern static void freeAdder(IntPtr ptr);

        [DllImport("Hello.dll")]
        extern static int adder_add(IntPtr p, int x, int y);

        static void Main(String[] args)
        {
            string str = StringGetter.getMagicString();
            Console.WriteLine(str);

            int x = doubleIt(2);
            Console.WriteLine(x);


            IntPtr ptr = establishAdder();
            int y = adder_add(ptr, 1, 2);
            Console.WriteLine(y);
            freeAdder(ptr);
        }
    }
}