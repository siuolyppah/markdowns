#ifndef ADDER_H
#define ADDER_H

#include<iostream>
using namespace std;

class Adder {
public:
	int add(int a, int b) {
		return a + b;
	}

	Adder() {
		cout << "Adder()" << endl;
	}

	~Adder() {
		cout << "~Adder()" << endl;
	}

};

#endif // !ADDER_H
