#include "pch.h"

#include "Adder.h"

extern "C" __declspec(dllexport)
int doubleIt(int x) {
	return x * 2;
}

extern "C" __declspec(dllexport)
Adder * establishAdder() {
	Adder* ptr = new Adder();

	return ptr;
}

extern "C" __declspec(dllexport)
void freeAdder(Adder * ptr) {
	delete ptr;
}

extern "C" __declspec(dllexport)
int adder_add(Adder* ptr,int a, int b) {
	return ptr->add(a, b);
}




