﻿namespace CSharpLib
{
    public class StringGetter
    {
        public static string getMagicString()
        {
            return "yep,it's C#12123";
        }
    }
}