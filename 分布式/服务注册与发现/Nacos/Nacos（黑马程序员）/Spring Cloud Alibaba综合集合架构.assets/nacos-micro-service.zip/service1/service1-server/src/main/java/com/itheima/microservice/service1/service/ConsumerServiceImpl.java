package com.itheima.microservice.service1.service;

import com.itheima.microservice.service1.api.ConsumerService;

@org.apache.dubbo.config.annotation.Service // 将此类的方法，暴露为Dubbo接口
public class ConsumerServiceImpl implements ConsumerService {

    @org.apache.dubbo.config.annotation.Reference
    com.itheima.microservice.service2.api.ConsumerService consumerService;

    @Override
    public String service() {
        String service = consumerService.service();
        return "Consumer Invoke" + service;
    }
}
