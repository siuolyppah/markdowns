package com.itheima.microservice.service1.api;

public interface ConsumerService {
    public String service();
}
