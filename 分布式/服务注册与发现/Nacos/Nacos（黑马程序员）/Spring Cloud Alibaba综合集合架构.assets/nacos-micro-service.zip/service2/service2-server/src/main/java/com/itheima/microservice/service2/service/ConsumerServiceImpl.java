package com.itheima.microservice.service2.service;

import com.itheima.microservice.service2.api.ConsumerService;

@org.apache.dubbo.config.annotation.Service
public class ConsumerServiceImpl implements ConsumerService {
    @Override
    public String service() {
        return "Consumer2 Invoke";
    }
}
