package com.itheima.microservice.service2.api;

public interface ConsumerService {
    public String service();
}
