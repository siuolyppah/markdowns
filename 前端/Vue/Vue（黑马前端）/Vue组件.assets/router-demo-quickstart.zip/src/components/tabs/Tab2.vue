<template>
  <div class="tab2-container">
    <h5>Tab2 组件</h5>
  </div>
</template>

<script>
export default {
  name: 'Tab2'
}
</script>

<style lang="less" scoped>
.tab2-container {
  min-height: 150px;
  background-color: plum;
}
</style>
