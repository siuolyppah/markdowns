import Vue from "vue";
import VueRouter from "vue-router";
import Home from "@/components/Home";
import Movie from "@/components/Movie";
import About from "@/components/About";

Vue.use(VueRouter)

const router = new VueRouter({
    routes: [
        {path: '/home', component: Home},
        {path: '/movie', component: Movie},
        {path: '/about', component: About},
    ]
})

export default router